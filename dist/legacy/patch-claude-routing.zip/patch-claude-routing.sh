#!/usr/bin/env bash
# Automated, version-independent installer for the Claude Code per-model API
# routing patch (+ gateway model discovery without a token + Agent-tool model
# schema relaxed to accept external/proxy model IDs).
#
# Effect: claude-* models -> https://api.anthropic.com (subscription/OAuth),
#         every other model -> process.env.ANTHROPIC_BASE_URL (your proxy).
#
# Method: byte-neutral in-binary patch of the bun-compiled Mach-O. The patcher
#   (patch_claude_routing.py) self-locates every site by structural regex, so it
#   adapts to the minified-identifier drift between releases; a dynamic reclaim
#   keeps the file size unchanged (all bun offsets + Mach-O sections stay valid).
#   Then re-sign with a stable identity, pinning the original bundle id so the
#   keychain OAuth grant survives. Original is backed up to <binary>.orig.
#
# Usage:
#   bash patch-claude-routing.sh                 # patch the active binary
#   bash patch-claude-routing.sh /path/to/binary # patch a specific binary
#   bash patch-claude-routing.sh --update [VER]   # download latest (or VER) from
#                                                 # npm, install, repoint symlink,
#                                                 # then patch
set -euo pipefail

PATCHER="$(cd "$(dirname "$0")" && pwd)/patch_claude_routing.py"
[[ -f "$PATCHER" ]] || { echo "ERROR: patch_claude_routing.py not found next to this script"; exit 1; }

# Version-independent sentinels (constants injected by the patch, NOT minified):
ROUTING_MARKER='baseURL:/^claude/i.test('        # routing edit (fixed idempotency sentinel)
ENUM_MARKER_RE='\.string\(\) {10}'               # enum edit (regex: .string() + padding run)

VERSIONS_DIR="$HOME/.local/share/claude/versions"
CLAUDE_LINK="$HOME/.local/bin/claude"

# --- optional --update: fetch a fresh native binary from the npm platform pkg --
BIN=""
if [[ "${1:-}" == "--update" ]]; then
  REQ_VER="${2:-}"
  # detect platform -> npm optional-dep suffix
  case "$(uname -s)" in Darwin) OS=darwin;; Linux) OS=linux;; *) echo "ERROR: unsupported OS"; exit 1;; esac
  case "$(uname -m)" in arm64|aarch64) ARCH=arm64;; x86_64) ARCH=x64;; *) echo "ERROR: unsupported arch"; exit 1;; esac
  PKG="@anthropic-ai/claude-code-${OS}-${ARCH}"
  if [[ -z "$REQ_VER" ]]; then
    REQ_VER="$(curl -fsSL https://registry.npmjs.org/-/package/@anthropic-ai/claude-code/dist-tags | python3 -c 'import sys,json;print(json.load(sys.stdin)["latest"])')"
  fi
  echo "Fetching $PKG@$REQ_VER ..."
  TB="$(curl -fsSL "https://registry.npmjs.org/${PKG}/${REQ_VER}" | python3 -c 'import sys,json;print(json.load(sys.stdin)["dist"]["tarball"])')"
  TD="$(mktemp -d)"; curl -fsSL "$TB" -o "$TD/pkg.tgz"; tar -xzf "$TD/pkg.tgz" -C "$TD"
  SRCBIN="$TD/package/claude"
  [[ -f "$SRCBIN" ]] || { echo "ERROR: native binary not found in package"; exit 1; }
  mkdir -p "$VERSIONS_DIR"
  BIN="$VERSIONS_DIR/$REQ_VER"
  cp -f "$SRCBIN" "$BIN"; chmod 0755 "$BIN"; rm -rf "$TD"
  echo "Installed pristine $REQ_VER -> $BIN"
  # repoint the active symlink to the new version
  mkdir -p "$(dirname "$CLAUDE_LINK")"
  ln -sfn "$BIN" "$CLAUDE_LINK"
  echo "Repointed $CLAUDE_LINK -> $BIN"
elif [[ -n "${1:-}" ]]; then
  BIN="$1"
fi

# --- resolve the active binary (follow the `claude` symlink) if not given ---
if [[ -z "$BIN" ]]; then
  CLAUDE_BIN="$(command -v claude || true)"
  [[ -z "$CLAUDE_BIN" ]] && { echo "ERROR: 'claude' not on PATH; pass the binary path explicitly."; exit 1; }
  BIN="$(readlink -f "$CLAUDE_BIN" 2>/dev/null || python3 -c 'import os,sys;print(os.path.realpath(sys.argv[1]))' "$CLAUDE_BIN")"
fi
[[ -f "$BIN" ]] || { echo "ERROR: binary not found: $BIN"; exit 1; }
echo "Target binary: $BIN"

# --- idempotency: already patched? (routing marker is a constant literal) ---
if LC_ALL=C grep -a -q -- "$ROUTING_MARKER" "$BIN"; then
  echo "Already patched — nothing to do."; exit 0
fi

# --- backup original (once) ---
BACKUP="$BIN.orig"
if [[ ! -f "$BACKUP" ]]; then
  cp -p "$BIN" "$BACKUP"; echo "Backed up original -> $BACKUP"
else
  echo "Backup already exists -> $BACKUP (keeping it)"
fi

# --- patch pristine -> temp ---
TMP="$(mktemp -t claude-patched.XXXXXX)"
python3 "$PATCHER" "$BACKUP" "$TMP"

# --- byte-neutral check BEFORE re-sign (re-signing legitimately resizes the
#     signature blob in __LINKEDIT; the patch itself is byte-neutral pre-sign). ---
[[ "$(stat -f%z "$TMP")" == "$(stat -f%z "$BACKUP")" ]] || { echo "ERROR: patch not byte-neutral (pre-sign)"; rm -f "$TMP"; exit 1; }

# --- re-sign with a STABLE identity, pinning the ORIGINAL bundle id so the
#     Designated Requirement (and thus the keychain OAuth grant) stays stable
#     across all future re-patches. Ad-hoc has no stable identity and is silently
#     denied keychain access ("Not logged in"). Override id via CLAUDE_PATCH_SIGN_ID. ---
CODESIGN_ID="com.anthropic.claude-code"
SIGN_ID="${CLAUDE_PATCH_SIGN_ID:-$(security find-identity -v -p codesigning 2>/dev/null | awk 'NR==1{print $2}')}"
if [[ -n "$SIGN_ID" && "$SIGN_ID" != "valid" ]]; then
  codesign -f -i "$CODESIGN_ID" -s "$SIGN_ID" "$TMP"
  echo "Re-signed with identity: $SIGN_ID (bundle id: $CODESIGN_ID)"
else
  codesign -f -i "$CODESIGN_ID" -s - "$TMP"
  echo "WARNING: no code-signing identity found -> signed ad-hoc; keychain/OAuth (subscription) will NOT work."
fi

# --- verify: launches + both markers present ---
echo "Patched --version: $("$TMP" --version 2>&1 | head -1 || true)"
LC_ALL=C grep -a -q -- "$ROUTING_MARKER" "$TMP" || { echo "ERROR: routing marker missing"; rm -f "$TMP"; exit 1; }
LC_ALL=C grep -aEq -- "$ENUM_MARKER_RE" "$TMP" || { echo "ERROR: enum marker missing"; rm -f "$TMP"; exit 1; }

# --- install in place ---
chmod 0755 "$TMP"; mv -f "$TMP" "$BIN"
echo "Installed patched binary over $BIN"
echo "Restore anytime with:  cp -p \"$BACKUP\" \"$BIN\""
